const fs = require('fs');
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tomatear')
    .setDescription('tomate')
    .addUserOption(o => o.setName('target').setDescription('target').setRequired(true)),

  async execute(interaction) {
    const statsFile = './tomato-stats.json';
    let stats = {};
    
    if (fs.existsSync(statsFile)) {
      try {
        stats = JSON.parse(fs.readFileSync(statsFile, 'utf8'));
      } catch {
        stats = {};
      }
    }
    
    const userId = interaction.user.id;
    const targetId = interaction.options.getUser('target').id;
    
    // Inicializar SIEMPRE con 0
    stats[userId] = stats[userId] || { lanzados: 0 };
    stats[targetId] = stats[targetId] || { recibidos: 0 };
    
    // Contar
    stats[userId].lanzados += 1;
    stats[targetId].recibidos += 1;
    
    fs.writeFileSync(statsFile, JSON.stringify(stats, null, 2));
    
    const total = Object.values(stats).reduce((s, u) => s + (u.lanzados || 0), 0);

    const embed = new EmbedBuilder()
      .setTitle('🍅')
      .setDescription(`<@${userId}> ha tomateado a <@${targetId}>`)
      .setColor('#ff4444')
      .addFields(
        { name: `${interaction.user.username}`, value: `**${stats[userId].lanzados}** lanzados`, inline: true },
        { name: `${interaction.options.getUser('target').username}`, value: `**${stats[targetId].recibidos}** recibidos`, inline: true },
        { name: 'Total', value: `**${total}**`, inline: true }
      )
      .setImage('https://media1.giphy.com/media/7vGrRUwK2pAEqKZXKE/giphy.mp4');

    await interaction.reply({ embeds: [embed] });
  }
};

